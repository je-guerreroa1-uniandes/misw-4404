
# Interconnection


Proyecto para analizar la calidad de código con respecto a su complejidad y resolver los problemas por medio de refactoring

