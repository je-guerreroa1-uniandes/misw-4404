package model.data_structures;

public class YaExisteException extends Exception
{
	public YaExisteException(String causa)
	{
		super(causa);
	}
	
	

}
