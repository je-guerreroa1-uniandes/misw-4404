package model.data_structures;

public class NullException extends Exception
{
	public NullException(String causa)
	{
		super(causa);
	}
}
