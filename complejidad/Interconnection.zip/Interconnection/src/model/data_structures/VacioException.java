package model.data_structures;

public class VacioException extends Exception
{
	public VacioException(String causa)
	{
		super(causa);
	}
}
