package model.data_structures;

public class PosException extends Exception
{
	public PosException(String causa)
	{
		super(causa);
	}
}
