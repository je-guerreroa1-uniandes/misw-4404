package editor;

public interface IIOHandler {
    String readInput();
    void writeOutput(String output);
}
