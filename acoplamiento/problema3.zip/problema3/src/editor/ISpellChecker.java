package editor;

import java.util.ArrayList;

public interface ISpellChecker {
    ArrayList<String> check(String text);
}
