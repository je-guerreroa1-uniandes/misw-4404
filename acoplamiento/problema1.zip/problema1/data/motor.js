class Motor {
  constructor() {
    this.velocidad = 0;
    this.rpm = 0;
    this.nivelAceite = 100;
    this.nivelGasolina = 100;
  }
}

module.exports = Motor;